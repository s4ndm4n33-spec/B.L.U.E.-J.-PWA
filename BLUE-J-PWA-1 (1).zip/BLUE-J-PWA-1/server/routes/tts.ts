import { Router } from "express";

const router = Router();

router.post("/", (_req, res) => {
  res.status(503).json({ error: "TTS not available in free mode. Use the browser's built-in speech synthesis instead." });
});

export default router;
