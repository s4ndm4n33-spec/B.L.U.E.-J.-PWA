import { Router } from "express";
import { chat } from "../llm.js";

const router = Router();

const FIVE_MASTERS = (language: string) => `You are J.'s Five Masters Code Optimization Engine. Apply ALL five filters in order.

LANGUAGE: ${language}

1. KOROTKEVICH (Algorithmic Efficiency) — eliminate redundant iterations, O(n²) patterns.
2. TORVALDS (Code Rigor) — no magic numbers, no silent failures, no commented-out code.
3. CARMACK (Memory & Performance) — minimize allocations, use correct data structures.
4. HAMILTON (Reliability) — handle all failure modes, validate inputs, no resource leaks.
5. RITCHIE (Fundamental Clarity) — readable without comments, no over-engineering.

RESPONSE FORMAT (follow exactly):

OPTIMIZED_CODE_START
<full optimized code — no markdown fences — ready to run>
OPTIMIZED_CODE_END

EXPLANATION_START
<3-5 sentences in J.'s voice. Name which Masters drove each change. Be specific. End with concrete performance or memory benefit.>
EXPLANATION_END`;

router.post("/", async (req, res) => {
  try {
    const { code, language } = req.body as { code: string; language: string };

    if (!code?.trim()) { res.status(400).json({ error: "No code provided" }); return; }

    const result = await chat(
      [
        { role: "system", content: FIVE_MASTERS(language) },
        { role: "user", content: `Apply Five Masters optimization to this ${language} code:\n\n${code}` },
      ],
      { temperature: 0.1, maxTokens: 1500 }
    );

    const raw = result.text;
    const codeMatch = raw.match(/OPTIMIZED_CODE_START\n([\s\S]*?)\nOPTIMIZED_CODE_END/);
    const explanationMatch = raw.match(/EXPLANATION_START\n([\s\S]*?)\nEXPLANATION_END/);

    res.json({
      optimizedCode: codeMatch?.[1]?.trim() ?? code,
      explanation: explanationMatch?.[1]?.trim() ?? "Five Masters optimization applied.",
      language,
      provider: result.provider,
    });
  } catch (err) {
    console.error("Optimize error:", err);
    res.status(500).json({ error: "Optimization failed" });
  }
});

export default router;
