import { Router } from "express";

const router = Router();

interface GitHubPushBody {
  token: string;
  owner: string;
  repo: string;
  code: string;
  language: string;
  filename?: string;
  commitMessage?: string;
  description?: string;
  isPrivate?: boolean;
}

function getFilename(language: string): string {
  switch (language) {
    case "python": return "main.py";
    case "cpp": return "main.cpp";
    case "javascript": return "main.js";
    default: return "main.txt";
  }
}

async function ghFetch(path: string, token: string, method = "GET", body?: unknown) {
  const res = await fetch(`https://api.github.com${path}`, {
    method,
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: "application/vnd.github+json",
      "X-GitHub-Api-Version": "2022-11-28",
      "Content-Type": "application/json",
      "User-Agent": "BLUEJ-AI-Simulator/1.0",
    },
    body: body ? JSON.stringify(body) : undefined,
  });
  const data = await res.json().catch(() => ({}));
  return { status: res.status, data };
}

router.post("/push", async (req, res) => {
  try {
    const { token, owner, repo, code, language, filename, commitMessage, description, isPrivate = false } =
      req.body as GitHubPushBody;

    if (!token?.trim()) { res.status(400).json({ error: "GitHub token is required." }); return; }
    if (!owner?.trim()) { res.status(400).json({ error: "GitHub username is required." }); return; }
    if (!repo?.trim()) { res.status(400).json({ error: "Repository name is required." }); return; }
    if (!code?.trim()) { res.status(400).json({ error: "No code to push." }); return; }

    const file = filename || getFilename(language);
    const message = commitMessage || `J. export — ${language} — ${new Date().toISOString().slice(0, 10)}`;

    const { status: authStatus } = await ghFetch("/user", token);
    if (authStatus === 401) {
      res.status(401).json({ error: "Invalid GitHub token." });
      return;
    }

    const { status: repoStatus } = await ghFetch(`/repos/${owner}/${repo}`, token);
    if (repoStatus === 404) {
      const { status: createStatus, data: createData } = await ghFetch("/user/repos", token, "POST", {
        name: repo,
        description: description || "Created by B.L.U.E.-J. AI Coding Simulator",
        private: isPrivate,
        auto_init: false,
      });
      if (createStatus !== 201) {
        res.status(500).json({ error: `Failed to create repository: ${(createData as Record<string, unknown>)?.message ?? "Unknown error"}` });
        return;
      }
      await new Promise((r) => setTimeout(r, 800));
    } else if (repoStatus !== 200) {
      res.status(500).json({ error: "Unable to access repository. Check your token permissions." });
      return;
    }

    const { status: fileStatus, data: fileData } = await ghFetch(`/repos/${owner}/${repo}/contents/${file}`, token);
    const existingSha = fileStatus === 200 ? (fileData as Record<string, unknown>)?.sha : undefined;

    const encodedContent = Buffer.from(code, "utf-8").toString("base64");
    const { status: putStatus, data: putData } = await ghFetch(
      `/repos/${owner}/${repo}/contents/${file}`, token, "PUT",
      { message, content: encodedContent, ...(existingSha ? { sha: existingSha } : {}) }
    );

    if (putStatus !== 200 && putStatus !== 201) {
      res.status(500).json({ error: `Failed to push file: ${(putData as Record<string, unknown>)?.message ?? "Unknown error"}` });
      return;
    }

    res.json({
      success: true,
      repoUrl: `https://github.com/${owner}/${repo}`,
      fileUrl: `https://github.com/${owner}/${repo}/blob/main/${file}`,
      created: repoStatus === 404,
      message: existingSha ? "File updated." : "File created.",
    });
  } catch (err) {
    console.error("GitHub push error:", err);
    res.status(500).json({ error: "An unexpected error occurred during GitHub push." });
  }
});

export default router;
