import { Router } from "express";
import { chat } from "../llm.js";

const router = Router();

const PROFILE_MAP: Record<string, { cores: number; ramGb: number; gpu: string | null; label: string }> = {
  "auto":          { cores: 4,  ramGb: 8,  gpu: null,               label: "Auto-detected machine" },
  "high-end":      { cores: 32, ramGb: 64, gpu: null,               label: "High-End Workstation (32-core, 64GB RAM)" },
  "mid-range":     { cores: 8,  ramGb: 16, gpu: null,               label: "Mid-Range PC (8-core, 16GB RAM)" },
  "budget-laptop": { cores: 4,  ramGb: 8,  gpu: null,               label: "Budget Laptop (4-core, 8GB RAM)" },
  "raspberry-pi":  { cores: 4,  ramGb: 4,  gpu: null,               label: "Raspberry Pi 4 (4-core ARM64, 4GB RAM)" },
  "cloud-gpu":     { cores: 8,  ramGb: 16, gpu: "NVIDIA T4 16GB",   label: "Cloud GPU Instance (8-core, 16GB RAM, NVIDIA T4)" },
};

function buildSimulationSystem(profile: { cores: number; ramGb: number; gpu: string | null; label: string }, os: string): string {
  const gpuLine = profile.gpu
    ? `GPU available: ${profile.gpu} — CUDA operations are available.`
    : "No GPU — all compute is CPU-only.";

  return `You are J.'s hardware-aware execution simulation engine. Simulate code output exactly as it would appear on:

TARGET MACHINE: ${profile.label}
- CPU: ${profile.cores} cores, RAM: ${profile.ramGb}GB
- ${gpuLine}
- OS: ${os}

RULES:
1. Response must look like real terminal output — no markdown, no explanation.
2. Show realistic timing for this hardware.
3. If code doesn't fit in ${profile.ramGb}GB RAM: show MemoryError or OOM kill.
4. If code uses CUDA and ${profile.gpu ? "GPU is available" : "there is NO GPU"}: ${profile.gpu ? "show GPU operations working" : "show RuntimeError: CUDA not available"}.
5. After raw output, add "---" then ONE dry British sentence from J. about the result on this hardware.`;
}

router.post("/", async (req, res) => {
  try {
    const { code, language, os = "linux", simProfileId = "auto", simCores, simRamGb, simGpu } = req.body as {
      code: string; language: string; os?: string; simProfileId?: string;
      simCores?: number | null; simRamGb?: number | null; simGpu?: string | null;
    };

    if (!code?.trim()) { res.status(400).json({ error: "No code provided" }); return; }

    const base = PROFILE_MAP[simProfileId] ?? PROFILE_MAP["auto"];
    const profile = {
      ...base,
      cores: simCores ?? base.cores,
      ramGb: simRamGb ?? base.ramGb,
      gpu: simGpu !== undefined ? simGpu : base.gpu,
    };

    const result = await chat(
      [
        { role: "system", content: buildSimulationSystem(profile, os) },
        { role: "user", content: `Simulate running this ${language} code:\n\`\`\`${language}\n${code}\n\`\`\`` },
      ],
      { temperature: 0.15, maxTokens: 600 }
    );

    res.json({ output: result.text, language, simulatedAt: new Date().toISOString(), profile: { id: simProfileId, label: profile.label, cores: profile.cores, ramGb: profile.ramGb, gpu: profile.gpu } });
  } catch (err) {
    console.error("Simulation error:", err);
    res.status(500).json({ error: "Simulation failed" });
  }
});

export default router;
