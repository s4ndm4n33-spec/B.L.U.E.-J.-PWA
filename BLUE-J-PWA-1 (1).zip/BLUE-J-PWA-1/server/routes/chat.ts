import { Router } from "express";
import { chat, type ChatMessage } from "../llm.js";
import { buildSystemPrompt, buildSafetyCheck } from "../personality.js";
import { CURRICULUM } from "../curriculum.js";

const router = Router();

const VALID_LEARNER_MODES = new Set(["kids", "teen", "adult-beginner", "advanced"]);
type LearnerMode = "kids" | "teen" | "adult-beginner" | "advanced";

function parseLearnerMode(raw: unknown): LearnerMode {
  if (typeof raw === "string" && VALID_LEARNER_MODES.has(raw)) return raw as LearnerMode;
  return "adult-beginner";
}

const STYLE_RULES: Record<string, string[]> = {
  python: [
    "1. snake_case for all variable and function names",
    "2. 4-space indentation",
    "3. Spaces around all operators",
    "4. Consistent string quotes",
    "5. Always specify exception type in except clauses",
  ],
  javascript: [
    "1. Use const for non-reassigned bindings; let for reassignable — never var",
    "2. Arrow functions for callbacks",
    "3. Template literals instead of string concatenation",
    "4. Strict equality ===",
    "5. camelCase for variables/functions, PascalCase for classes",
  ],
  typescript: [
    "1. Explicit types on all function parameters and return values",
    "2. const/let only — never var",
    "3. Template literals",
    "4. Strict equality ===",
    "5. camelCase for identifiers, PascalCase for types/interfaces/classes",
  ],
  cpp: [
    "1. #pragma once or proper include guards in every header",
    "2. Pass large objects by const reference",
    "3. Use nullptr instead of NULL",
    "4. Prefer std::string over raw char*",
    "5. Initialize every variable at declaration",
  ],
};

function resolveRules(lang: string): string[] {
  if (lang.includes("python") || lang === "py") return STYLE_RULES.python;
  if (lang.includes("typescript") || lang === "ts" || lang === "tsx") return STYLE_RULES.typescript;
  if (lang.includes("javascript") || lang === "js" || lang === "jsx") return STYLE_RULES.javascript;
  if (lang.includes("c++") || lang === "cpp" || lang === "c") return STYLE_RULES.cpp;
  return STYLE_RULES.python;
}

async function runCodeGauntlet(code: string, language: string): Promise<{ passed: boolean; violations: string[] }> {
  if (!code || code.length < 20) return { passed: true, violations: [] };
  const rules = resolveRules(language).join("\n");
  try {
    const result = await chat(
      [
        { role: "system", content: "You are a strict code quality auditor. Respond only in raw JSON." },
        {
          role: "user",
          content: `Audit this ${language} code against ONLY these 5 style rules:\n${rules}\n\nCODE:\n\`\`\`${language}\n${code}\n\`\`\`\n\nRespond ONLY in valid JSON: {"passed": true|false, "violations": ["..."]}`,
        },
      ],
      { temperature: 0, maxTokens: 300, jsonMode: true }
    );
    const parsed = JSON.parse(result.text) as { passed?: boolean; violations?: string[] };
    return { passed: parsed.passed !== false, violations: Array.isArray(parsed.violations) ? parsed.violations : [] };
  } catch {
    return { passed: true, violations: [] };
  }
}

function extractCodeBlocks(text: string): Array<{ lang: string; code: string }> {
  const blocks: Array<{ lang: string; code: string }> = [];
  const regex = /```([\w+#.-]+)?\n([\s\S]*?)```/g;
  let match: RegExpExecArray | null;
  while ((match = regex.exec(text)) !== null) {
    const lang = (match[1] ?? "python").toLowerCase();
    const code = match[2]?.trim() ?? "";
    if (code.length > 10) blocks.push({ lang, code });
  }
  return blocks;
}

const sessionHistory = new Map<string, ChatMessage[]>();

router.post("/", async (req, res) => {
  try {
    const {
      message,
      sessionId,
      phaseIndex = 0,
      taskIndex = 0,
      language = "python",
      os = "linux",
      hardwareInfo,
      learnerMode: rawLearnerMode,
      conversationId,
    } = req.body as {
      message: string;
      sessionId: string;
      phaseIndex?: number;
      taskIndex?: number;
      language?: string;
      os?: string;
      hardwareInfo?: { cpuCores?: number | null; ramGb?: number | null; platform?: string | null } | null;
      learnerMode?: unknown;
      conversationId?: number | null;
    };

    const learnerMode = parseLearnerMode(rawLearnerMode);

    const safety = buildSafetyCheck(message);
    if (!safety.safe) {
      res.setHeader("Content-Type", "text/event-stream");
      res.setHeader("Cache-Control", "no-cache");
      res.setHeader("Connection", "keep-alive");
      res.write(`data: ${JSON.stringify({ content: safety.reason })}\n\n`);
      res.write(`data: ${JSON.stringify({ done: true, conversationId: conversationId ?? null })}\n\n`);
      return res.end();
    }

    const historyKey = sessionId ?? "default";
    const messageHistory = sessionHistory.get(historyKey) ?? [];

    const currentPhase = CURRICULUM[phaseIndex] ?? null;
    const currentTask = currentPhase?.tasks[taskIndex] ?? null;

    const systemPrompt = buildSystemPrompt({
      phaseIndex,
      taskIndex,
      currentPhase,
      currentTask,
      language,
      os,
      hardwareInfo: hardwareInfo as { cpuCores?: number | null; ramGb?: number | null; platform?: string | null } | null,
      messageHistory: messageHistory.map((m) => ({ role: m.role as string, content: m.content })),
      learnerMode,
    });

    const chatMessages: ChatMessage[] = [
      { role: "system", content: systemPrompt },
      ...messageHistory.slice(-20),
      { role: "user", content: message },
    ];

    const result = await chat(chatMessages, { temperature: 0.7, maxTokens: 1024 });
    let fullResponse = result.text;

    const codeBlocks = extractCodeBlocks(fullResponse);
    if (codeBlocks.length > 0) {
      const gauntlet = await runCodeGauntlet(codeBlocks[0].code, language);
      if (!gauntlet.passed && gauntlet.violations.length > 0) {
        fullResponse += `\n\n> **Code Gauntlet:** ${gauntlet.violations.join(" | ")}`;
      }
    }

    const updatedHistory = [...messageHistory, { role: "user" as const, content: message }, { role: "assistant" as const, content: fullResponse }];
    sessionHistory.set(historyKey, updatedHistory.slice(-40));

    res.setHeader("Content-Type", "text/event-stream");
    res.setHeader("Cache-Control", "no-cache");
    res.setHeader("Connection", "keep-alive");

    const CHUNK = 20;
    for (let i = 0; i < fullResponse.length; i += CHUNK) {
      res.write(`data: ${JSON.stringify({ content: fullResponse.slice(i, i + CHUNK) })}\n\n`);
    }

    res.write(`data: ${JSON.stringify({ done: true, conversationId: conversationId ?? null })}\n\n`);
    res.end();
  } catch (err) {
    console.error("Chat error:", err);
    if (!res.headersSent) {
      res.status(500).json({ error: "Chat failed" });
    } else {
      res.write(`data: ${JSON.stringify({ error: "Internal error", done: true })}\n\n`);
      res.end();
    }
  }
});

export default router;
