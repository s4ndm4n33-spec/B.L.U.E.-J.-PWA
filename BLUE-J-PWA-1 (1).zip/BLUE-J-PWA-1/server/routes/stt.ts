import { Router } from "express";

const router = Router();

router.post("/", (_req, res) => {
  res.status(503).json({ error: "STT not available in free mode. Use the browser's built-in speech recognition instead." });
});

export default router;
