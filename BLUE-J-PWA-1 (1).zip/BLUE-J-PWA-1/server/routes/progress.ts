import { Router } from "express";

const router = Router();

interface ProgressRecord {
  sessionId: string;
  currentPhase: number;
  currentTask: number;
  completedTasks: string[];
  selectedLanguage: string;
  selectedOs: string;
  conversationId?: number | null;
}

const store = new Map<string, ProgressRecord>();

function getOrCreate(sessionId: string): ProgressRecord {
  if (!store.has(sessionId)) {
    store.set(sessionId, {
      sessionId,
      currentPhase: 0,
      currentTask: 0,
      completedTasks: [],
      selectedLanguage: "python",
      selectedOs: "linux",
      conversationId: null,
    });
  }
  return store.get(sessionId)!;
}

router.get("/", (req, res) => {
  const sessionId = String(req.query.sessionId ?? "");
  if (!sessionId) {
    res.status(400).json({ error: "sessionId required" });
    return;
  }
  res.json(getOrCreate(sessionId));
});

router.post("/task", (req, res) => {
  const { sessionId, phaseIndex, taskIndex, language, os, conversationId } = req.body as {
    sessionId: string;
    phaseIndex: number;
    taskIndex: number;
    language: string;
    os: string;
    conversationId?: number | null;
  };

  if (!sessionId) {
    res.status(400).json({ error: "sessionId required" });
    return;
  }

  const progress = getOrCreate(sessionId);
  const taskKey = `p${phaseIndex}t${taskIndex}`;

  if (!progress.completedTasks.includes(taskKey)) {
    progress.completedTasks.push(taskKey);
  }

  if (phaseIndex >= progress.currentPhase) {
    progress.currentPhase = phaseIndex;
    progress.currentTask = taskIndex + 1;
  }

  progress.selectedLanguage = language ?? progress.selectedLanguage;
  progress.selectedOs = os ?? progress.selectedOs;
  if (conversationId !== undefined) progress.conversationId = conversationId;

  res.json(progress);
});

export default router;
