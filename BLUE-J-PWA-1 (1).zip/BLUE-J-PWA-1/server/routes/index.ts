import { Router } from "express";
import chatRouter from "./chat.js";
import diagnosticRouter from "./diagnostic.js";
import simulateRouter from "./simulate.js";
import optimizeRouter from "./optimize.js";
import executeRouter from "./execute.js";
import progressRouter from "./progress.js";
import githubRouter from "./github.js";
import ttsRouter from "./tts.js";
import sttRouter from "./stt.js";

const router = Router();

router.get("/healthz", (_req, res) => res.json({ status: "ok" }));

router.use("/bluej/chat", chatRouter);
router.use("/bluej/diagnostic", diagnosticRouter);
router.use("/bluej/simulate", simulateRouter);
router.use("/bluej/optimize", optimizeRouter);
router.use("/bluej/execute", executeRouter);
router.use("/bluej/progress", progressRouter);
router.use("/bluej/github", githubRouter);
router.use("/bluej/tts", ttsRouter);
router.use("/bluej/stt", sttRouter);

export default router;
