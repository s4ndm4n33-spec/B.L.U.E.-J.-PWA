import { Router } from "express";
import { chat } from "../llm.js";

const router = Router();

function computeHardwareStatus(cpuCores?: number | null, ramGb?: number | null): "optimal" | "adequate" | "constrained" {
  const cores = cpuCores ?? 0;
  const ram = ramGb ?? 0;
  if (cores >= 8 && ram >= 16) return "optimal";
  if (cores >= 4 && ram >= 8) return "adequate";
  return "constrained";
}

router.post("/", async (req, res) => {
  try {
    const { cpuCores, ramGb } = req.body as { sessionId?: string; cpuCores?: number | null; ramGb?: number | null };

    const hardwareStatus = computeHardwareStatus(cpuCores, ramGb);
    const hwDesc = cpuCores || ramGb ? `CPU: ${cpuCores ?? "?"}×cores, RAM: ${ramGb ?? "?"}GB` : "hardware telemetry unavailable";

    const diagPrompt = [
      "System diagnostic clearance — J.'s voice, under 55 words, 2 sentences max.",
      `Hardware: ${hwDesc}. Status: ${hardwareStatus.toUpperCase()}.`,
      "No orphaned records found.",
      "New operator session initialized.",
      "Be dry, precise, and British. End with one hardware-specific recommendation.",
    ].join(" ");

    let jSummary = "Systems nominal. Shall we proceed?";
    try {
      const result = await chat(
        [
          { role: "system", content: "You are J. from B.L.U.E.-J. — dry wit, precise, British. Keep it under 55 words." },
          { role: "user", content: diagPrompt },
        ],
        { temperature: 0.7, maxTokens: 120 }
      );
      jSummary = result.text;
    } catch {
      jSummary = "Diagnostic inconclusive. Shall we proceed regardless?";
    }

    res.json({ orphanedConversations: 0, orphanedMessages: 0, sessionExists: false, hardwareStatus, jSummary });
  } catch (err) {
    console.error("Diagnostic error:", err);
    res.status(500).json({
      orphanedConversations: 0,
      orphanedMessages: 0,
      sessionExists: false,
      hardwareStatus: "adequate" as const,
      jSummary: "Diagnostic inconclusive. Shall we proceed regardless?",
    });
  }
});

export default router;
