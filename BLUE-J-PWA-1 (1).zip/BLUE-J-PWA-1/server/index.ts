import "dotenv/config";
import express from "express";
import cors from "cors";
import router from "./routes/index.js";
import { activeProviderNames } from "./llm.js";

const app = express();
const PORT = parseInt(process.env.SERVER_PORT ?? "3001", 10);

app.use(cors({ origin: true }));
app.use(express.json({ limit: "50mb" }));
app.use(express.urlencoded({ extended: true, limit: "50mb" }));

app.use("/api", router);

app.listen(PORT, "0.0.0.0", () => {
  console.log(`[B.L.U.E.-J. API] Listening on port ${PORT}`);
  const providers = activeProviderNames();
  if (providers.length === 0) {
    console.warn("[B.L.U.E.-J. API] WARNING: No LLM provider keys found. Add GROQ_API_KEY, TOGETHER_API_KEY, or OPENROUTER_API_KEY.");
  } else {
    console.log(`[B.L.U.E.-J. API] LLM providers active: ${providers.join(" \u2192 ")}`);
  }
});
