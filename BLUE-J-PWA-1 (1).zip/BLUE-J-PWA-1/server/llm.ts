import OpenAI from "openai";

interface Provider {
  name: string;
  baseURL: string;
  apiKey: string | undefined;
  model: string;
}

const PROVIDERS: Provider[] = [
  {
    name: "Groq",
    baseURL: "https://api.groq.com/openai/v1",
    apiKey: process.env.GROQ_API_KEY,
    model: "llama-3.3-70b-versatile",
  },
  {
    name: "Together AI",
    baseURL: "https://api.together.xyz/v1",
    apiKey: process.env.TOGETHER_API_KEY,
    model: "meta-llama/Llama-3.3-70B-Instruct-Turbo-Free",
  },
  {
    name: "OpenRouter",
    baseURL: "https://openrouter.ai/api/v1",
    apiKey: process.env.OPENROUTER_API_KEY,
    model: "meta-llama/llama-3.3-70b-instruct:free",
  },
];

export type ChatMessage = { role: "system" | "user" | "assistant"; content: string };

function getActiveProviders(): Provider[] {
  return PROVIDERS.filter((p) => p.apiKey && p.apiKey.trim().length > 0);
}

export async function chat(
  messages: ChatMessage[],
  opts: { temperature?: number; maxTokens?: number; jsonMode?: boolean } = {}
): Promise<{ text: string; provider: string }> {
  const active = getActiveProviders();
  if (active.length === 0) {
    throw new Error("No LLM provider keys configured. Add GROQ_API_KEY, TOGETHER_API_KEY, or OPENROUTER_API_KEY.");
  }

  const errors: string[] = [];

  for (const provider of active) {
    try {
      const client = new OpenAI({
        baseURL: provider.baseURL,
        apiKey: provider.apiKey!,
        defaultHeaders:
          provider.name === "OpenRouter"
            ? { "HTTP-Referer": "https://bluej.app", "X-Title": "B.L.U.E.-J." }
            : undefined,
      });

      const params: OpenAI.Chat.ChatCompletionCreateParamsNonStreaming = {
        model: provider.model,
        messages,
        temperature: opts.temperature ?? 0.7,
        max_tokens: opts.maxTokens ?? 1024,
      };

      if (opts.jsonMode && provider.name === "Groq") {
        params.response_format = { type: "json_object" };
      }

      const res = await client.chat.completions.create(params);
      const text = res.choices[0]?.message?.content ?? "";
      return { text, provider: provider.name };
    } catch (err: unknown) {
      const msg = err instanceof Error ? err.message : String(err);
      console.warn(`[LLM] ${provider.name} failed: ${msg}`);
      errors.push(`${provider.name}: ${msg}`);
    }
  }

  throw new Error(`All providers failed:\n${errors.join("\n")}`);
}

export function activeProviderNames(): string[] {
  return getActiveProviders().map((p) => p.name);
}
